import React, { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useTweetData } from "@/hooks/useTweetData";
import { SentimentByLocationData } from "@/types";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface MapMarker {
  lat: string;
  lng: string;
  sentiment: "positive" | "negative" | "neutral";
  intensity: number;
}

export default function GeographicView() {
  const { tweetCount, sentimentByLocation } = useTweetData();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [markers, setMarkers] = useState<MapMarker[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // This is a placeholder for actual map integration
  // In a real implementation, we would use Mapbox or Leaflet
  useEffect(() => {
    if (sentimentByLocation) {
      // Generate markers from sentiment data
      const newMarkers: MapMarker[] = [];
      
      sentimentByLocation.forEach(location => {
        // This is simplified logic to determine dominant sentiment
        const total = location.positive + location.negative + location.neutral;
        let sentiment: "positive" | "negative" | "neutral" = "neutral";
        let intensity = 0.5; // Default medium intensity
        
        if (location.positive > location.negative && location.positive > location.neutral) {
          sentiment = "positive";
          intensity = location.positive / total;
        } else if (location.negative > location.positive && location.negative > location.neutral) {
          sentiment = "negative";
          intensity = location.negative / total;
        } else {
          sentiment = "neutral";
          intensity = location.neutral / total;
        }
        
        // Extract coordinates from location data
        // Format: "City, State" - we'd need to geocode this in a real implementation
        const parts = location.location.split(',');
        if (parts.length >= 2) {
          // Mock coordinates for demo (would come from geocoding API in real app)
          const mockCoordinates = {
            "Charlotte": { lat: "35.2271", lng: "-80.8431" },
            "Raleigh": { lat: "35.7796", lng: "-78.6382" },
            "Wilmington": { lat: "34.2104", lng: "-77.8868" },
            "Greensboro": { lat: "36.0726", lng: "-79.7920" },
            "Durham": { lat: "35.9940", lng: "-78.8986" },
            "Winston-Salem": { lat: "36.0999", lng: "-80.2442" },
            "Fayetteville": { lat: "35.0527", lng: "-78.8784" },
            "Cary": { lat: "35.7915", lng: "-78.7811" }
          };
          
          const city = parts[0].trim();
          if (mockCoordinates[city as keyof typeof mockCoordinates]) {
            const coords = mockCoordinates[city as keyof typeof mockCoordinates];
            newMarkers.push({
              lat: coords.lat,
              lng: coords.lng,
              sentiment,
              intensity
            });
          }
        }
      });
      
      setMarkers(newMarkers);
    }
  }, [sentimentByLocation]);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
    // In a real implementation, we would toggle actual fullscreen mode
  };

  const getLocationDetails = (locationName: string) => {
    if (!sentimentByLocation) return null;
    return sentimentByLocation.find(loc => loc.location.includes(locationName));
  };

  const handleMarkerClick = (location: string) => {
    setSelectedLocation(location);
  };

  return (
    <Card className={`shadow ${isFullscreen ? 'fixed inset-0 z-50 rounded-none' : ''}`}>
      <CardHeader className="border-b border-neutral-200 flex justify-between items-center p-4">
        <CardTitle className="font-semibold text-neutral-900 text-lg">Geographic Sentiment Analysis</CardTitle>
        <div className="flex space-x-2">
          <button 
            className="p-1 rounded text-neutral-500 hover:bg-neutral-100"
            onClick={toggleFullscreen}
          >
            <span className="material-icons">{isFullscreen ? 'fullscreen_exit' : 'fullscreen'}</span>
          </button>
          <button className="p-1 rounded text-neutral-500 hover:bg-neutral-100">
            <span className="material-icons">more_vert</span>
          </button>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div 
          ref={mapContainerRef}
          className={`${isFullscreen ? 'h-[calc(100vh-65px)]' : 'h-[400px]'} relative bg-gray-100`}
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1526778548025-fa2f459cd5ce?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')",
            backgroundSize: "cover",
            backgroundPosition: "center"
          }}
        >
          {/* Map overlay legend */}
          <div className="absolute bottom-4 left-4 bg-white bg-opacity-90 p-3 rounded-md shadow-md text-sm">
            <h3 className="font-medium mb-2">Sentiment Intensity</h3>
            <div className="flex items-center space-x-2 mb-1">
              <span className="block w-4 h-4 rounded-full bg-red-500"></span>
              <span>Negative</span>
            </div>
            <div className="flex items-center space-x-2 mb-1">
              <span className="block w-4 h-4 rounded-full bg-gray-500"></span>
              <span>Neutral</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="block w-4 h-4 rounded-full bg-green-500"></span>
              <span>Positive</span>
            </div>
          </div>
          
          {/* Tweet volume indicator */}
          <div className="absolute top-4 right-4 bg-white bg-opacity-90 p-2 rounded-md shadow-md text-sm">
            <div className="flex items-center">
              <span className="pulse-indicator bg-primary mr-2"></span>
              <span><span className="font-medium">{tweetCount.toLocaleString()}</span> tweets in view</span>
            </div>
          </div>
          
          {/* Location detail popup */}
          {selectedLocation && (
            <div className="absolute top-4 left-4 bg-white bg-opacity-95 p-4 rounded-md shadow-lg max-w-xs">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">{selectedLocation}</h3>
                <button 
                  className="text-neutral-500 hover:text-neutral-700"
                  onClick={() => setSelectedLocation(null)}
                >
                  <span className="material-icons text-sm">close</span>
                </button>
              </div>
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span>Positive</span>
                    <span className="text-green-600">45%</span>
                  </div>
                  <Progress value={45} className="h-2 bg-gray-200" indicatorClassName="bg-green-500" />
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span>Neutral</span>
                    <span className="text-gray-600">30%</span>
                  </div>
                  <Progress value={30} className="h-2 bg-gray-200" indicatorClassName="bg-gray-500" />
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span>Negative</span>
                    <span className="text-red-600">25%</span>
                  </div>
                  <Progress value={25} className="h-2 bg-gray-200" indicatorClassName="bg-red-500" />
                </div>
              </div>
              <div className="mt-3 text-xs text-neutral-600">
                <div className="flex justify-between">
                  <span>Total tweets:</span>
                  <span className="font-medium">325</span>
                </div>
                <div className="flex justify-between">
                  <span>Last update:</span>
                  <span className="font-medium">2 min ago</span>
                </div>
              </div>
            </div>
          )}
          
          {/* Render simple circle markers for demonstration */}
          {markers.map((marker, index) => {
            // Note: This is a simplified visualization - in a real app we'd use a mapping library
            const color = marker.sentiment === "positive" 
              ? "bg-green-500" 
              : marker.sentiment === "negative" 
                ? "bg-red-500" 
                : "bg-gray-500";
                
            const size = Math.max(20, Math.min(50, marker.intensity * 50));
            
            // Simplified positioning based on lat/lng (not accurate)
            // In a real app, we'd use the mapping library's projection
            const left = (parseFloat(marker.lng) + 82) * 50; // simplified positioning
            const top = (38 - parseFloat(marker.lat)) * 50; // simplified positioning
            
            // Find location name based on coordinates
            const locationName = Object.entries({
              "Charlotte": { lat: "35.2271", lng: "-80.8431" },
              "Raleigh": { lat: "35.7796", lng: "-78.6382" },
              "Wilmington": { lat: "34.2104", lng: "-77.8868" },
              "Greensboro": { lat: "36.0726", lng: "-79.7920" },
              "Durham": { lat: "35.9940", lng: "-78.8986" },
              "Winston-Salem": { lat: "36.0999", lng: "-80.2442" },
              "Fayetteville": { lat: "35.0527", lng: "-78.8784" },
              "Cary": { lat: "35.7915", lng: "-78.7811" }
            }).find(([_, coords]) => coords.lat === marker.lat && coords.lng === marker.lng)?.[0] || "";
            
            return (
              <div 
                key={index}
                className={`absolute rounded-full opacity-70 ${color} cursor-pointer hover:opacity-90 transition-all`}
                style={{
                  width: `${size}px`,
                  height: `${size}px`,
                  left: `${left}px`,
                  top: `${top}px`
                }}
                onClick={() => handleMarkerClick(locationName)}
                title={locationName}
              />
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
