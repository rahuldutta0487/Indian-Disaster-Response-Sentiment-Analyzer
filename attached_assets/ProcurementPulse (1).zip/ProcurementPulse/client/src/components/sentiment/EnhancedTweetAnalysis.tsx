import React, { useState } from "react";
import { 
  EnhancedSentimentResult, 
  Entity, 
  SentimentCategory, 
  EntityType, 
  useEnhancedTweetSentiment 
} from "@/hooks/useEnhancedSentiment";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  AlertCircle, 
  Lightbulb, 
  MapPin, 
  Zap, 
  Package, 
  AlertTriangle, 
  Clock, 
  Users, 
  FileQuestion,
  MessageSquare
} from "lucide-react";
import { cn } from "@/lib/utils";

interface EnhancedTweetAnalysisProps {
  tweetId: number | null;
}

export function EnhancedTweetAnalysis({ tweetId }: EnhancedTweetAnalysisProps) {
  const { data, isLoading, error } = useEnhancedTweetSentiment(tweetId);
  const [activeTab, setActiveTab] = useState("overview");

  if (!tweetId) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle>Enhanced Analysis</CardTitle>
          <CardDescription>
            Select a tweet to view enhanced sentiment analysis
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (isLoading) {
    return <EnhancedTweetAnalysisSkeleton />;
  }

  if (error || !data) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle>Analysis Error</CardTitle>
          <CardDescription>
            Failed to load sentiment analysis
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64 text-muted-foreground">
            <AlertCircle className="mr-2" size={20} />
            <span>Error loading analysis</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full overflow-hidden flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <span>Enhanced Sentiment Analysis</span>
          <SentimentBadge sentiment={data.sentiment} />
        </CardTitle>
        <CardDescription>
          Confidence: {(data.confidence * 100).toFixed(0)}%
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-1 pb-0 overflow-hidden">
        <Tabs 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="h-full flex flex-col"
        >
          <TabsList className="grid grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="entities">Entities</TabsTrigger>
            <TabsTrigger value="emotions">Emotions</TabsTrigger>
          </TabsList>
          
          <TabsContent 
            value="overview" 
            className="flex-1 overflow-auto mt-4 data-[state=inactive]:hidden"
          >
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium mb-1">Impact Assessment</h4>
                <p className="text-sm border p-2 rounded-md bg-muted/30">
                  {data.impactAssessment}
                </p>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-1">Sentiment Score</h4>
                <div className="relative h-4 w-full bg-muted rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "absolute h-full", 
                      data.sentimentScore < 0 
                        ? "right-1/2 bg-red-500" 
                        : "left-1/2 bg-green-500"
                    )}
                    style={{ 
                      width: `${Math.abs(data.sentimentScore) * 50}%`,
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="h-1 w-1 bg-background rounded-full"></div>
                  </div>
                </div>
                <div className="flex justify-between text-xs mt-1">
                  <span>Very Negative</span>
                  <span>Very Positive</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <MetricCard 
                  title="Urgency" 
                  value={data.urgency} 
                  icon={<Zap size={16} />} 
                />
                <MetricCard 
                  title="Actionability" 
                  value={data.actionability} 
                  icon={<Lightbulb size={16} />} 
                />
              </div>

              {data.resourceNeeds.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium mb-2">Resource Needs</h4>
                  <div className="flex flex-wrap gap-1">
                    {data.resourceNeeds.map(need => (
                      <Badge key={need} variant="outline" className="bg-blue-500/10">
                        <Package size={12} className="mr-1 text-blue-500" />
                        {need}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {data.safetyThreats.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium mb-2">Safety Threats</h4>
                  <div className="flex flex-wrap gap-1">
                    {data.safetyThreats.map(threat => (
                      <Badge key={threat} variant="outline" className="bg-red-500/10">
                        <AlertTriangle size={12} className="mr-1 text-red-500" />
                        {threat}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {data.topKeywords.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium mb-2">Key Terms</h4>
                  <div className="flex flex-wrap gap-1">
                    {data.topKeywords.map(keyword => (
                      <Badge key={keyword} variant="secondary">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent 
            value="entities" 
            className="flex-1 overflow-auto mt-4 data-[state=inactive]:hidden"
          >
            {data.entities.length === 0 ? (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                No entities detected
              </div>
            ) : (
              <div className="space-y-4">
                <EntityList 
                  entities={data.entities.filter(e => e.type === 'location')} 
                  title="Locations" 
                  icon={<MapPin size={16} />}
                  className="bg-blue-500/10"
                />
                <EntityList 
                  entities={data.entities.filter(e => e.type === 'resource')} 
                  title="Resources" 
                  icon={<Package size={16} />}
                  className="bg-green-500/10"
                />
                <EntityList 
                  entities={data.entities.filter(e => e.type === 'hazard')} 
                  title="Hazards" 
                  icon={<AlertTriangle size={16} />}
                  className="bg-red-500/10"
                />
                <EntityList 
                  entities={data.entities.filter(e => e.type === 'action')} 
                  title="Actions" 
                  icon={<Lightbulb size={16} />}
                  className="bg-amber-500/10"
                />
                <EntityList 
                  entities={data.entities.filter(e => e.type === 'time')} 
                  title="Time References" 
                  icon={<Clock size={16} />}
                  className="bg-purple-500/10"
                />
                <EntityList 
                  entities={data.entities.filter(e => e.type === 'person')} 
                  title="People & Organizations" 
                  icon={<Users size={16} />}
                  className="bg-indigo-500/10"
                />
                <EntityList 
                  entities={data.entities.filter(e => e.type === 'impact')} 
                  title="Impact" 
                  icon={<AlertCircle size={16} />}
                  className="bg-rose-500/10"
                />
                <EntityList 
                  entities={data.entities.filter(e => e.type === 'other')} 
                  title="Other Entities" 
                  icon={<FileQuestion size={16} />}
                  className="bg-gray-500/10"
                />
              </div>
            )}
          </TabsContent>
          
          <TabsContent 
            value="emotions" 
            className="flex-1 overflow-auto mt-4 data-[state=inactive]:hidden"
          >
            {Object.keys(data.emotionalStates).length === 0 ? (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                No emotional states detected
              </div>
            ) : (
              <div className="space-y-4">
                {Object.entries(data.emotionalStates).map(([emotion, intensity]) => (
                  <div key={emotion}>
                    <div className="flex justify-between items-center mb-1">
                      <h4 className="text-sm font-medium capitalize">
                        {emotion}
                      </h4>
                      <span className="text-xs text-muted-foreground">
                        {(intensity * 100).toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={intensity * 100} className="h-2" />
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

function EnhancedTweetAnalysisSkeleton() {
  return (
    <Card className="h-full">
      <CardHeader>
        <Skeleton className="h-6 w-48" />
        <Skeleton className="h-4 w-32 mt-2" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-4 w-full" />
          <div className="grid grid-cols-2 gap-3">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
          <div className="space-y-2">
            <Skeleton className="h-4 w-32" />
            <div className="flex flex-wrap gap-1">
              <Skeleton className="h-6 w-20" />
              <Skeleton className="h-6 w-24" />
              <Skeleton className="h-6 w-16" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface EntityListProps {
  entities: Entity[];
  title: string;
  icon: React.ReactNode;
  className?: string;
}

function EntityList({ entities, title, icon, className }: EntityListProps) {
  if (entities.length === 0) return null;
  
  return (
    <div>
      <h4 className="text-sm font-medium mb-2 flex items-center">
        {icon}
        <span className="ml-1">{title}</span>
      </h4>
      <div className="flex flex-wrap gap-1">
        {entities.map((entity, i) => (
          <Badge 
            key={`${entity.text}-${i}`} 
            variant="outline" 
            className={className}>
            {entity.text}
            <span className="ml-1 text-xs opacity-70">
              {(entity.confidence * 100).toFixed(0)}%
            </span>
          </Badge>
        ))}
      </div>
    </div>
  );
}

interface MetricCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
}

function MetricCard({ title, value, icon }: MetricCardProps) {
  return (
    <div className="border rounded-md p-2">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-xs font-medium flex items-center">
          {icon}
          <span className="ml-1">{title}</span>
        </h4>
        <span className="text-xs font-medium">
          {(value * 100).toFixed(0)}%
        </span>
      </div>
      <Progress value={value * 100} className="h-1.5" />
    </div>
  );
}

interface SentimentBadgeProps {
  sentiment: SentimentCategory;
}

function SentimentBadge({ sentiment }: SentimentBadgeProps) {
  const getColor = () => {
    switch (sentiment) {
      case 'very_negative':
        return 'bg-red-500 text-white';
      case 'negative':
        return 'bg-red-300 text-white';
      case 'slightly_negative':
        return 'bg-red-100 text-red-800';
      case 'neutral':
        return 'bg-gray-200 text-gray-800';
      case 'slightly_positive':
        return 'bg-green-100 text-green-800';
      case 'positive':
        return 'bg-green-300 text-white';
      case 'very_positive':
        return 'bg-green-500 text-white';
      default:
        return 'bg-gray-200 text-gray-800';
    }
  };
  
  return (
    <Badge className={cn('px-2 py-0.5 rounded-md', getColor())}>
      <MessageSquare size={12} className="mr-1" />
      {sentiment.split('_').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
      ).join(' ')}
    </Badge>
  );
}