import { useQuery } from "@tanstack/react-query";

export type SentimentCategory = 
  | 'very_negative' 
  | 'negative' 
  | 'slightly_negative' 
  | 'neutral' 
  | 'slightly_positive' 
  | 'positive' 
  | 'very_positive';

export type EntityType = 
  | 'location'
  | 'resource'
  | 'hazard'
  | 'impact'
  | 'action'
  | 'time'
  | 'person'
  | 'other';

export interface Entity {
  text: string;
  type: EntityType;
  confidence: number;
}

export interface EnhancedSentimentResult {
  sentiment: SentimentCategory;
  sentimentScore: number;
  confidence: number;
  emotionalStates: Record<string, number>;
  entities: Entity[];
  urgency: number;
  actionability: number;
  topKeywords: string[];
  resourceNeeds: string[];
  safetyThreats: string[];
  impactAssessment: string;
}

export interface DisasterSentimentAnalysis {
  sentimentDistribution: Record<SentimentCategory, number>;
  topEntities: {
    type: string;
    text: string;
    count: number;
  }[];
  averageUrgency: number;
  topResourceNeeds: {
    need: string;
    count: number;
  }[];
  topSafetyThreats: {
    threat: string;
    count: number;
  }[];
  emotionalStateTrends: {
    emotion: string;
    averageIntensity: number;
    occurrenceRate: number;
  }[];
}

export function useEnhancedTweetSentiment(tweetId: number | null) {
  return useQuery<EnhancedSentimentResult>({
    queryKey: ['/api/enhanced-sentiment/tweet', tweetId],
    enabled: tweetId !== null,
  });
}

export function useDisasterSentimentAnalysis(disasterId: number | null) {
  return useQuery<DisasterSentimentAnalysis>({
    queryKey: ['/api/enhanced-sentiment/disaster', disasterId],
    enabled: disasterId !== null,
  });
}