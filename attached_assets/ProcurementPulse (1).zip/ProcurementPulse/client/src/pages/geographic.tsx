import React, { useState } from "react";
import { GeographicView } from "@/components/dashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useTweetData } from "@/hooks/useTweetData";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDisaster } from "@/context/DisasterContext";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function Geographic() {
  const { tweetCount, sentimentByLocation } = useTweetData();
  const { currentDisaster } = useDisaster();
  const [activeTab, setActiveTab] = useState("heatmap");
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null);
  
  // Mock data for regional breakdown
  const regions = [
    { name: "Wilmington, NC", positive: 45, neutral: 30, negative: 25, total: 325, risk: "high" },
    { name: "Raleigh, NC", positive: 50, neutral: 40, negative: 10, total: 280, risk: "low" },
    { name: "Charlotte, NC", positive: 35, neutral: 25, negative: 40, total: 410, risk: "medium" },
    { name: "Durham, NC", positive: 60, neutral: 30, negative: 10, total: 185, risk: "low" },
    { name: "Greensboro, NC", positive: 30, neutral: 40, negative: 30, total: 220, risk: "medium" }
  ];

  // Mock data for hotspots
  const hotspots = [
    { 
      id: 1, 
      location: "Wilmington, NC", 
      intensity: 82, 
      sentiment: "negative",
      trend: "increasing",
      keywords: ["flooding", "evacuation", "damage"] 
    },
    { 
      id: 2, 
      location: "Outer Banks, NC", 
      intensity: 74, 
      sentiment: "negative",
      trend: "stable",
      keywords: ["beach", "erosion", "winds"] 
    },
    { 
      id: 3, 
      location: "Jacksonville, NC", 
      intensity: 65, 
      sentiment: "negative",
      trend: "decreasing",
      keywords: ["marines", "shelter", "water"] 
    }
  ];

  const getSentimentColor = (sentiment: string) => {
    if (sentiment === "positive") return "bg-green-500";
    if (sentiment === "negative") return "bg-red-500";
    return "bg-gray-500";
  };

  const getRiskBadge = (risk: string) => {
    if (risk === "high") return <Badge className="bg-red-500 hover:bg-red-600">High Risk</Badge>;
    if (risk === "medium") return <Badge className="bg-yellow-500 hover:bg-yellow-600">Medium Risk</Badge>;
    return <Badge className="bg-green-500 hover:bg-green-600">Low Risk</Badge>;
  };

  const getTrendIcon = (trend: string) => {
    if (trend === "increasing") return <span className="material-icons text-red-500">trending_up</span>;
    if (trend === "decreasing") return <span className="material-icons text-green-500">trending_down</span>;
    return <span className="material-icons text-gray-500">trending_flat</span>;
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900 mb-2">Geographic Analysis</h1>
        <p className="text-neutral-600">
          Visualize sentiment data across affected geographical regions.
        </p>
      </div>
      
      <div className="mb-6">
        <GeographicView />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow">
          <CardHeader className="border-b border-neutral-200 p-4 flex flex-row justify-between items-center">
            <CardTitle className="font-semibold text-neutral-900 text-lg">Regional Sentiment Breakdown</CardTitle>
            <div className="flex space-x-2">
              <button className="p-1 rounded text-neutral-500 hover:bg-neutral-100">
                <span className="material-icons">pie_chart</span>
              </button>
            </div>
          </CardHeader>
          
          <CardContent className="p-4">
            {regions.length > 0 ? (
              <div className="space-y-4">
                {regions.map((region, index) => (
                  <div key={index} className="border rounded-md p-3 hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-medium">{region.name}</h3>
                      {getRiskBadge(region.risk)}
                    </div>
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Positive</span>
                          <span className="text-green-600">{region.positive}%</span>
                        </div>
                        <Progress value={region.positive} className="h-2 bg-gray-200" indicatorClassName="bg-green-500" />
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Neutral</span>
                          <span className="text-gray-600">{region.neutral}%</span>
                        </div>
                        <Progress value={region.neutral} className="h-2 bg-gray-200" indicatorClassName="bg-gray-500" />
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span>Negative</span>
                          <span className="text-red-600">{region.negative}%</span>
                        </div>
                        <Progress value={region.negative} className="h-2 bg-gray-200" indicatorClassName="bg-red-500" />
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-right text-neutral-600">
                      <span className="font-medium">{region.total.toLocaleString()}</span> tweets
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <span className="material-icons text-5xl text-neutral-300 mb-4">pie_chart</span>
                <h3 className="text-xl font-medium text-neutral-700 mb-2">Regional Data</h3>
                <p className="text-neutral-500 max-w-md mx-auto">
                  No regional sentiment data available for the current selection.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card className="shadow">
          <CardHeader className="border-b border-neutral-200 p-4">
            <CardTitle className="font-semibold text-neutral-900 text-lg">Hotspot Detection</CardTitle>
          </CardHeader>
          
          <CardContent className="p-4">
            {hotspots.length > 0 ? (
              <div className="space-y-4">
                {hotspots.map((hotspot) => (
                  <div key={hotspot.id} className="border rounded-md p-3 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="material-icons text-red-500">local_fire_department</span>
                        <h3 className="font-medium">{hotspot.location}</h3>
                      </div>
                      <div className="flex items-center">
                        <span className="text-sm font-semibold mr-1">Intensity: {hotspot.intensity}%</span>
                        {getTrendIcon(hotspot.trend)}
                      </div>
                    </div>
                    
                    <div className="mb-2">
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className={`${getSentimentColor(hotspot.sentiment)} h-3 rounded-full`}
                          style={{ width: `${hotspot.intensity}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-1 mt-2">
                      {hotspot.keywords.map((keyword, i) => (
                        <Badge key={i} variant="outline" className="bg-gray-100">{keyword}</Badge>
                      ))}
                    </div>
                  </div>
                ))}
                
                <div className="text-center mt-6">
                  <Button variant="outline">
                    <span className="material-icons text-sm mr-1">refresh</span>
                    Update Hotspots
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <span className="material-icons text-5xl text-neutral-300 mb-4">local_fire_department</span>
                <h3 className="text-xl font-medium text-neutral-700 mb-2">Hotspot Analysis</h3>
                <p className="text-neutral-500 max-w-md mx-auto">
                  No sentiment hotspots detected in the current area.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
