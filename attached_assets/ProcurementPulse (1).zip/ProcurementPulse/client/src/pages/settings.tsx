import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDisaster } from "@/context/DisasterContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Keyword, User } from "@/types";

export default function Settings() {
  const { currentDisaster } = useDisaster();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newKeyword, setNewKeyword] = useState('');
  const [showAddUserForm, setShowAddUserForm] = useState(false);
  const [newUser, setNewUser] = useState({
    username: '',
    fullName: '',
    role: '',
    password: ''
  });
  
  // Fetch keywords
  const { data: keywords = [] } = useQuery({
    queryKey: [`/api/disasters/${currentDisaster?.id}/keywords`],
    enabled: !!currentDisaster?.id,
  });
  
  // Add keyword mutation
  const addKeywordMutation = useMutation({
    mutationFn: async (keyword: string) => {
      const isHashtag = keyword.startsWith('#');
      const keywordText = isHashtag ? keyword.substring(1) : keyword;
      
      return apiRequest('POST', `/api/disasters/${currentDisaster?.id}/keywords`, {
        keyword: keywordText,
        isHashtag,
        isActive: true,
        disasterId: currentDisaster?.id
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/disasters/${currentDisaster?.id}/keywords`] });
      setNewKeyword('');
      toast({
        title: "Keyword added",
        description: "The keyword was added successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add keyword. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Toggle keyword active state mutation
  const toggleKeywordMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      return apiRequest('PATCH', `/api/keywords/${id}`, {
        isActive
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/disasters/${currentDisaster?.id}/keywords`] });
      toast({
        title: "Keyword updated",
        description: "The keyword status was updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update keyword. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Delete keyword mutation
  const deleteKeywordMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest('DELETE', `/api/keywords/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/disasters/${currentDisaster?.id}/keywords`] });
      toast({
        title: "Keyword deleted",
        description: "The keyword was removed successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete keyword. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  const handleAddKeyword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyword.trim()) return;
    
    addKeywordMutation.mutate(newKeyword);
  };
  
  const handleToggleKeyword = (id: number, isActive: boolean) => {
    toggleKeywordMutation.mutate({ id, isActive: !isActive });
  };
  
  const handleDeleteKeyword = (id: number) => {
    if (confirm('Are you sure you want to delete this keyword?')) {
      deleteKeywordMutation.mutate(id);
    }
  };

  // Fetch users for the user management tab
  const { 
    data: users = [], 
    isLoading: isLoadingUsers 
  } = useQuery({
    queryKey: ['/api/users'],
  });

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (userData: typeof newUser) => {
      return apiRequest('POST', '/api/users', userData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setNewUser({
        username: '',
        fullName: '',
        role: '',
        password: ''
      });
      setShowAddUserForm(false);
      toast({
        title: "User created",
        description: "The user account was created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create user. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleAddUser = () => {
    // Form validation
    if (!newUser.username.trim()) {
      toast({
        title: "Validation Error",
        description: "Username is required",
        variant: "destructive"
      });
      return;
    }
    
    if (!newUser.password.trim()) {
      toast({
        title: "Validation Error",
        description: "Password is required",
        variant: "destructive"
      });
      return;
    }
    
    if (!newUser.fullName.trim()) {
      toast({
        title: "Validation Error",
        description: "Full name is required",
        variant: "destructive"
      });
      return;
    }
    
    if (!newUser.role.trim()) {
      toast({
        title: "Validation Error",
        description: "Role is required",
        variant: "destructive"
      });
      return;
    }
    
    createUserMutation.mutate(newUser);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900 mb-2">Settings</h1>
        <p className="text-neutral-600">
          Configure monitoring parameters and system settings.
        </p>
      </div>
      
      <Tabs defaultValue="keywords" className="mb-6">
        <TabsList className="mb-4">
          <TabsTrigger value="keywords">Keywords</TabsTrigger>
          <TabsTrigger value="filters">Filters</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
        </TabsList>
        
        <TabsContent value="keywords">
          <Card className="shadow mb-6">
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-neutral-900 text-lg">Keyword Management</CardTitle>
            </CardHeader>
            
            <CardContent className="p-4">
              <form onSubmit={handleAddKeyword} className="mb-6">
                <div className="flex mb-4">
                  <Input
                    value={newKeyword}
                    onChange={(e) => setNewKeyword(e.target.value)}
                    placeholder="Add new keyword or hashtag (e.g. flood or #rescue)"
                    className="rounded-r-none"
                  />
                  <Button 
                    type="submit" 
                    className="rounded-l-none"
                    disabled={addKeywordMutation.isPending}
                  >
                    {addKeywordMutation.isPending ? "Adding..." : "Add Keyword"}
                  </Button>
                </div>
                <p className="text-sm text-neutral-500">
                  Add keywords or hashtags to monitor in social media posts. 
                  Prefix with # to indicate a hashtag.
                </p>
              </form>
              
              <div className="border-t border-neutral-200 pt-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-medium">Active Keywords</h3>
                  <div className="flex items-center">
                    <Input 
                      placeholder="Search keywords..." 
                      className="text-sm h-8 w-40 mr-2" 
                    />
                    <select className="h-8 rounded-md border border-input bg-background px-2 py-1 text-xs ring-offset-background">
                      <option value="all">All Types</option>
                      <option value="hashtag">Hashtags Only</option>
                      <option value="keyword">Keywords Only</option>
                    </select>
                  </div>
                </div>
                
                {keywords.length === 0 ? (
                  <p className="text-neutral-500 text-center py-4">No keywords configured yet</p>
                ) : (
                  <div className="space-y-3">
                    {keywords.map((keyword: Keyword) => (
                      <div key={keyword.id} className="flex items-center justify-between p-3 bg-neutral-50 rounded-md border border-transparent hover:border-neutral-200 transition-colors">
                        <div className="flex items-center">
                          <Switch
                            checked={keyword.isActive}
                            onCheckedChange={() => handleToggleKeyword(keyword.id, keyword.isActive)}
                          />
                          <span className="ml-3 font-medium">
                            {keyword.isHashtag ? '#' : ''}{keyword.keyword}
                          </span>
                          {keyword.isHashtag ? (
                            <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700 border-blue-200">Hashtag</Badge>
                          ) : (
                            <Badge variant="outline" className="ml-2 bg-purple-50 text-purple-700 border-purple-200">Keyword</Badge>
                          )}
                        </div>
                        <div className="flex items-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => handleDeleteKeyword(keyword.id)}
                            disabled={deleteKeywordMutation.isPending}
                          >
                            <span className="material-icons text-sm text-neutral-500">delete</span>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow">
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-neutral-900 text-lg">Keyword Analytics & Insights</CardTitle>
            </CardHeader>
            
            <CardContent className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-green-50 rounded-md p-3 border border-green-100">
                  <div className="flex items-center mb-1">
                    <span className="material-icons text-green-600 mr-2">trending_up</span>
                    <h3 className="font-medium text-green-800">Top Performing</h3>
                  </div>
                  <div className="text-sm text-green-700 mb-2">Keywords with highest engagement</div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">evacuation</span>
                      <span>152 mentions</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">#NCwx</span>
                      <span>137 mentions</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">flooding</span>
                      <span>98 mentions</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-amber-50 rounded-md p-3 border border-amber-100">
                  <div className="flex items-center mb-1">
                    <span className="material-icons text-amber-600 mr-2">trending_flat</span>
                    <h3 className="font-medium text-amber-800">Emerging</h3>
                  </div>
                  <div className="text-sm text-amber-700 mb-2">Keywords with growing activity</div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">shelter</span>
                      <span>+42% today</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">power outage</span>
                      <span>+28% today</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">#HurricaneFlorence</span>
                      <span>+22% today</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-red-50 rounded-md p-3 border border-red-100">
                  <div className="flex items-center mb-1">
                    <span className="material-icons text-red-600 mr-2">trending_down</span>
                    <h3 className="font-medium text-red-800">Underperforming</h3>
                  </div>
                  <div className="text-sm text-red-700 mb-2">Keywords with low engagement</div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">relief efforts</span>
                      <span>5 mentions</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">#relief</span>
                      <span>3 mentions</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="font-medium">assistance</span>
                      <span>2 mentions</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-neutral-200 pt-4 mb-4">
                <h3 className="font-medium mb-3">Suggested Keywords</h3>
                <p className="text-sm text-neutral-500 mb-3">
                  Based on current trends and disaster context, consider adding these keywords to your monitoring:
                </p>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-4">
                  <Button variant="outline" size="sm" className="justify-start" onClick={() => setNewKeyword("#recovery")}>
                    <span className="mr-1">+</span> #recovery
                  </Button>
                  <Button variant="outline" size="sm" className="justify-start" onClick={() => setNewKeyword("road closure")}>
                    <span className="mr-1">+</span> road closure
                  </Button>
                  <Button variant="outline" size="sm" className="justify-start" onClick={() => setNewKeyword("power restoration")}>
                    <span className="mr-1">+</span> power restoration
                  </Button>
                  <Button variant="outline" size="sm" className="justify-start" onClick={() => setNewKeyword("#HurricaneUpdate")}>
                    <span className="mr-1">+</span> #HurricaneUpdate
                  </Button>
                  <Button variant="outline" size="sm" className="justify-start" onClick={() => setNewKeyword("volunteers")}>
                    <span className="mr-1">+</span> volunteers
                  </Button>
                  <Button variant="outline" size="sm" className="justify-start" onClick={() => setNewKeyword("emergency shelter")}>
                    <span className="mr-1">+</span> emergency shelter
                  </Button>
                </div>
              </div>
              
              <div className="border-t border-neutral-200 pt-4">
                <h3 className="font-medium mb-3">Keyword Groups</h3>
                <p className="text-sm text-neutral-500 mb-3">
                  Organize related keywords into groups for better analysis and filtering:
                </p>
                
                <div className="space-y-3">
                  <div className="p-3 bg-neutral-50 rounded-md border">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Emergency Resources</h4>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                          <span className="material-icons text-xs">edit</span>
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                          <span className="material-icons text-xs">delete</span>
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1 mb-1">
                      <Badge variant="outline" className="bg-neutral-100">water</Badge>
                      <Badge variant="outline" className="bg-neutral-100">food</Badge>
                      <Badge variant="outline" className="bg-neutral-100">shelter</Badge>
                      <Badge variant="outline" className="bg-neutral-100">supplies</Badge>
                      <Badge variant="outline" className="bg-neutral-100">#relief</Badge>
                    </div>
                  </div>
                  
                  <div className="p-3 bg-neutral-50 rounded-md border">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Infrastructure</h4>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                          <span className="material-icons text-xs">edit</span>
                        </Button>
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                          <span className="material-icons text-xs">delete</span>
                        </Button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1 mb-1">
                      <Badge variant="outline" className="bg-neutral-100">road</Badge>
                      <Badge variant="outline" className="bg-neutral-100">bridge</Badge>
                      <Badge variant="outline" className="bg-neutral-100">power</Badge>
                      <Badge variant="outline" className="bg-neutral-100">electricity</Badge>
                      <Badge variant="outline" className="bg-neutral-100">outage</Badge>
                    </div>
                  </div>
                  
                  <Button variant="outline" className="w-full">
                    <span className="material-icons text-sm mr-1">add</span>
                    Add Keyword Group
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="filters">
          <Card className="shadow">
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-neutral-900 text-lg">Filter Rules</CardTitle>
            </CardHeader>
            
            <CardContent className="p-4">
              <div className="space-y-6">
                <div>
                  <h3 className="text-md font-medium mb-3">Content Filters</h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-neutral-50 rounded-md">
                      <div>
                        <Label htmlFor="filter-retweets" className="font-medium">Filter Retweets</Label>
                        <p className="text-xs text-neutral-500">Hide content that has been retweeted</p>
                      </div>
                      <Switch id="filter-retweets" defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-neutral-50 rounded-md">
                      <div>
                        <Label htmlFor="filter-replies" className="font-medium">Filter Replies</Label>
                        <p className="text-xs text-neutral-500">Hide content that is a reply to another post</p>
                      </div>
                      <Switch id="filter-replies" />
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-neutral-50 rounded-md">
                      <div>
                        <Label htmlFor="filter-low-engagement" className="font-medium">Filter Low Engagement</Label>
                        <p className="text-xs text-neutral-500">Hide content with low engagement metrics</p>
                      </div>
                      <Switch id="filter-low-engagement" defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-neutral-50 rounded-md">
                      <div>
                        <Label htmlFor="filter-spam" className="font-medium">Filter Spam/Bot Content</Label>
                        <p className="text-xs text-neutral-500">Hide content detected as spam or from bot accounts</p>
                      </div>
                      <Switch id="filter-spam" defaultChecked />
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-neutral-200 pt-4">
                  <h3 className="text-md font-medium mb-3">Geographic Filters</h3>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label htmlFor="distance-filter" className="font-medium">Distance Filter</Label>
                      <div className="flex mt-2 mb-4">
                        <Input id="distance-filter" type="number" defaultValue="50" min="0" max="1000" className="w-24 rounded-r-none" />
                        <select className="rounded-l-none border border-input bg-background px-3 py-2 text-sm ring-offset-background">
                          <option value="mi">Miles</option>
                          <option value="km">Kilometers</option>
                        </select>
                      </div>
                      <p className="text-xs text-neutral-500">Show content within this distance of the disaster center</p>
                    </div>
                    
                    <div>
                      <Label htmlFor="priority-regions" className="font-medium">Priority Regions</Label>
                      <Input id="priority-regions" className="mt-2 mb-1" placeholder="e.g. Wilmington, Charlotte" />
                      <p className="text-xs text-neutral-500">Prioritize content from these regions (comma separated)</p>
                    </div>
                  </div>
                  
                  <div className="bg-blue-50 rounded-md p-3 text-sm mb-3">
                    <div className="flex">
                      <span className="material-icons text-blue-600 mr-2">info</span>
                      <span className="text-blue-700">Geographic filters only apply to content with location data available</span>
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-neutral-200 pt-4">
                  <h3 className="text-md font-medium mb-3">Advanced Rule Builder</h3>
                  
                  <div className="bg-neutral-50 rounded-md p-4 mb-4">
                    <div className="mb-3">
                      <Label htmlFor="rule-name" className="font-medium">Rule Name</Label>
                      <Input id="rule-name" className="mt-1" placeholder="e.g. High Priority Content" />
                    </div>
                    
                    <div className="space-y-3 mb-4">
                      <div className="flex items-center">
                        <select className="min-w-24 rounded-l-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
                          <option value="contains">Contains</option>
                          <option value="not_contains">Does not contain</option>
                          <option value="starts_with">Starts with</option>
                          <option value="ends_with">Ends with</option>
                        </select>
                        <Input className="rounded-none border-l-0" placeholder="Keyword or phrase" />
                        <select className="rounded-r-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
                          <option value="and">AND</option>
                          <option value="or">OR</option>
                        </select>
                        <Button variant="outline" size="sm" className="ml-2">
                          <span className="material-icons text-sm">add</span>
                        </Button>
                      </div>
                      
                      <div className="flex items-center">
                        <select className="min-w-24 rounded-l-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
                          <option value="sentiment">Sentiment</option>
                          <option value="language">Language</option>
                          <option value="verified">Account Verified</option>
                          <option value="followers">Follower Count</option>
                        </select>
                        <select className="border border-input bg-background px-3 py-2 text-sm ring-offset-background border-l-0">
                          <option value="equals">Equals</option>
                          <option value="not_equals">Not equals</option>
                          <option value="greater_than">Greater than</option>
                          <option value="less_than">Less than</option>
                        </select>
                        <Input className="rounded-r-md border-l-0" placeholder="Value" />
                        <Button variant="outline" size="sm" className="ml-2">
                          <span className="material-icons text-sm">remove</span>
                        </Button>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <Label htmlFor="rule-action" className="font-medium">Action</Label>
                      <select id="rule-action" className="w-full rounded-md border border-input bg-background px-3 py-2 mt-1 text-sm ring-offset-background">
                        <option value="highlight">Highlight Content</option>
                        <option value="categorize">Categorize As</option>
                        <option value="alert">Generate Alert</option>
                        <option value="hide">Hide Content</option>
                      </select>
                    </div>
                    
                    <div className="pt-3 border-t border-neutral-200 flex justify-end">
                      <Button variant="outline" className="mr-2">Cancel</Button>
                      <Button>Save Rule</Button>
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <h4 className="text-sm font-medium mb-2">Saved Rules</h4>
                    <div className="space-y-2">
                      <div className="p-3 border rounded-md flex justify-between items-center">
                        <div>
                          <span className="font-medium">High Priority Content</span>
                          <p className="text-xs text-neutral-500">Contains "rescue" OR "emergency" AND Sentiment equals "negative"</p>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm">
                            <span className="material-icons text-sm">edit</span>
                          </Button>
                          <Button variant="ghost" size="sm">
                            <span className="material-icons text-sm">delete</span>
                          </Button>
                        </div>
                      </div>
                      
                      <div className="p-3 border rounded-md flex justify-between items-center">
                        <div>
                          <span className="font-medium">Verified Sources Only</span>
                          <p className="text-xs text-neutral-500">Account Verified equals "true"</p>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm">
                            <span className="material-icons text-sm">edit</span>
                          </Button>
                          <Button variant="ghost" size="sm">
                            <span className="material-icons text-sm">delete</span>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-neutral-200 flex justify-end">
                  <Button className="w-full sm:w-auto">Save All Filter Settings</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card className="shadow">
            <CardHeader className="border-b border-neutral-200 p-4">
              <CardTitle className="font-semibold text-neutral-900 text-lg">Notification Settings</CardTitle>
            </CardHeader>
            
            <CardContent className="p-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="browser-notifications" className="font-medium">Browser Notifications</Label>
                    <p className="text-sm text-neutral-500">Get notified in your browser</p>
                  </div>
                  <Switch id="browser-notifications" defaultChecked />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-notifications" className="font-medium">Email Notifications</Label>
                    <p className="text-sm text-neutral-500">Receive alerts via email</p>
                  </div>
                  <Switch id="email-notifications" />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="sms-notifications" className="font-medium">SMS Notifications</Label>
                    <p className="text-sm text-neutral-500">Receive critical alerts via SMS</p>
                  </div>
                  <Switch id="sms-notifications" />
                </div>
                
                <div className="pt-4 border-t border-neutral-200">
                  <Button>Save Notification Settings</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="account">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="shadow">
              <CardHeader className="border-b border-neutral-200 p-4">
                <CardTitle className="font-semibold text-neutral-900 text-lg">Account Settings</CardTitle>
              </CardHeader>
              
              <CardContent className="p-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name" className="font-medium">Full Name</Label>
                    <Input id="name" defaultValue="Jamie Davis" className="mt-1" />
                  </div>
                  
                  <div>
                    <Label htmlFor="username" className="font-medium">Username</Label>
                    <Input id="username" defaultValue="jdavis" className="mt-1" />
                  </div>
                  
                  <div>
                    <Label htmlFor="role" className="font-medium">Role</Label>
                    <Input id="role" defaultValue="Disaster Response Coordinator" className="mt-1" />
                  </div>
                  
                  <div>
                    <Label htmlFor="password" className="font-medium">New Password</Label>
                    <Input id="password" type="password" placeholder="Leave blank to keep current password" className="mt-1" />
                  </div>
                  
                  <div className="pt-4 border-t border-neutral-200">
                    <Button>Save Account Settings</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow">
              <CardHeader className="border-b border-neutral-200 p-4">
                <div className="flex justify-between items-center">
                  <CardTitle className="font-semibold text-neutral-900 text-lg">User Management</CardTitle>
                  <Button size="sm" variant="outline" onClick={() => setShowAddUserForm(prev => !prev)}>
                    {showAddUserForm ? "Cancel" : "Add User"}
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-4">
                {showAddUserForm ? (
                  <div className="space-y-4 mb-6 border p-4 rounded-md bg-gray-50">
                    <h3 className="text-md font-medium">Add New User</h3>
                    <div>
                      <Label htmlFor="new-username" className="font-medium">Username</Label>
                      <Input 
                        id="new-username" 
                        value={newUser.username} 
                        onChange={e => setNewUser({...newUser, username: e.target.value})}
                        className="mt-1" 
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="new-full-name" className="font-medium">Full Name</Label>
                      <Input 
                        id="new-full-name" 
                        value={newUser.fullName}
                        onChange={e => setNewUser({...newUser, fullName: e.target.value})}
                        className="mt-1" 
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="new-role" className="font-medium">Role</Label>
                      <Input 
                        id="new-role" 
                        value={newUser.role}
                        onChange={e => setNewUser({...newUser, role: e.target.value})}
                        className="mt-1" 
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="new-password" className="font-medium">Password</Label>
                      <Input 
                        id="new-password" 
                        type="password"
                        value={newUser.password}
                        onChange={e => setNewUser({...newUser, password: e.target.value})}
                        className="mt-1" 
                      />
                    </div>
                    
                    <Button 
                      onClick={handleAddUser} 
                      disabled={createUserMutation.isPending}
                    >
                      {createUserMutation.isPending ? "Creating..." : "Create User"}
                    </Button>
                  </div>
                ) : null}
                
                <div className="space-y-4">
                  {isLoadingUsers ? (
                    <div className="text-center py-4">Loading users...</div>
                  ) : (
                    <div className="space-y-3">
                      {users && users.map(user => (
                        <div key={user.id} className="p-3 border rounded-md flex justify-between items-center">
                          <div>
                            <div className="font-medium">{user.fullName}</div>
                            <div className="text-sm text-neutral-500">@{user.username} · {user.role}</div>
                          </div>
                          <div>
                            <Button variant="ghost" size="sm">Edit</Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
