import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingTopics, SentimentOverview } from "@/components/dashboard";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function Trends() {
  const [activeExtendedTab, setActiveExtendedTab] = useState("patterns");
  const [showComingSoon, setShowComingSoon] = useState(true);

  // Mock data for advanced trend analysis
  const patternGroups = [
    {
      id: 1,
      name: "Evacuation Concerns",
      keywords: ["evacuation", "leave", "escape", "flee", "relocate"],
      growth: 34,
      sentiment: "negative",
      timeframe: "24h"
    },
    {
      id: 2,
      name: "Resource Requests",
      keywords: ["water", "food", "shelter", "supplies", "medicine"],
      growth: 28,
      sentiment: "neutral",
      timeframe: "24h"
    },
    {
      id: 3,
      name: "Infrastructure Issues",
      keywords: ["road", "power", "electricity", "bridge", "closed"],
      growth: 42,
      sentiment: "negative",
      timeframe: "24h"
    }
  ];

  const toggleViewMode = () => {
    setShowComingSoon(!showComingSoon);
  };

  const getSentimentColor = (sentiment: string) => {
    if (sentiment === "positive") return "bg-green-500 text-white";
    if (sentiment === "negative") return "bg-red-500 text-white";
    return "bg-gray-500 text-white";
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900 mb-2">Trend Analysis</h1>
        <p className="text-neutral-600">
          Analyze social media trends and sentiment patterns over time.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <SentimentOverview />
        <TrendingTopics />
      </div>
      
      <Card className="shadow">
        <CardHeader className="border-b border-neutral-200 p-4 flex justify-between items-center">
          <CardTitle className="font-semibold text-neutral-900 text-lg">Extended Trend Analysis</CardTitle>
          <Button 
            variant="outline" 
            size="sm"
            onClick={toggleViewMode}
          >
            {showComingSoon ? "Show Preview" : "Reset View"}
          </Button>
        </CardHeader>
        
        <CardContent className="p-4">
          {showComingSoon ? (
            <div className="text-center py-12">
              <span className="material-icons text-5xl text-neutral-300 mb-4">trending_up</span>
              <h3 className="text-xl font-medium text-neutral-700 mb-2">Extended Trend Analysis</h3>
              <p className="text-neutral-500 max-w-md mx-auto">
                Advanced trend visualization and pattern recognition will be available in a future update.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <Tabs defaultValue="patterns" className="w-full" onValueChange={setActiveExtendedTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="patterns">Pattern Recognition</TabsTrigger>
                  <TabsTrigger value="predictive">Predictive Analytics</TabsTrigger>
                  <TabsTrigger value="correlation">Correlation Analysis</TabsTrigger>
                </TabsList>
                <TabsContent value="patterns">
                  <div className="rounded-md bg-blue-50 p-4 mb-6">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <span className="material-icons text-blue-500">info</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="text-sm font-medium text-blue-800">About Pattern Recognition</h3>
                        <div className="mt-2 text-sm text-blue-700">
                          <p>
                            Our machine learning algorithms identify emerging word patterns and cluster related topics to help identify key concerns during disaster response.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    {patternGroups.map(group => (
                      <div key={group.id} className="border rounded-md p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex justify-between items-center mb-3">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-semibold text-lg">{group.name}</h3>
                            <Badge className={getSentimentColor(group.sentiment)}>
                              {group.sentiment.charAt(0).toUpperCase() + group.sentiment.slice(1)}
                            </Badge>
                          </div>
                          <div className="flex items-center">
                            <span className="material-icons text-green-500 mr-1">trending_up</span>
                            <span className="text-sm font-medium text-green-600">+{group.growth}% in {group.timeframe}</span>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-3">
                          {group.keywords.map((keyword, index) => (
                            <Badge key={index} variant="outline" className="bg-gray-100">
                              {keyword}
                            </Badge>
                          ))}
                        </div>
                        
                        <div>
                          <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-2 ${group.sentiment === 'positive' ? 'bg-green-500' : group.sentiment === 'negative' ? 'bg-red-500' : 'bg-gray-500'}`}
                              style={{ width: `${group.growth * 2}%` }}
                            ></div>
                          </div>
                          <div className="flex justify-between text-xs mt-1 text-gray-500">
                            <span>Growth Rate</span>
                            <span>{group.growth}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="predictive">
                  <div className="rounded-md bg-blue-50 p-4 mb-6">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <span className="material-icons text-blue-500">info</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="text-sm font-medium text-blue-800">Predictive Analytics</h3>
                        <div className="mt-2 text-sm text-blue-700">
                          <p>
                            Our predictive models forecast likely sentiment changes and topic evolution based on historical disaster data and current trends.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <Card>
                      <CardHeader className="p-3">
                        <CardTitle className="text-base">Resource Needs Prediction</CardTitle>
                      </CardHeader>
                      <CardContent className="p-3">
                        <div className="space-y-3">
                          <div>
                            <div className="flex justify-between mb-1 text-sm">
                              <span>Clean Water</span>
                              <span className="font-medium">87%</span>
                            </div>
                            <Progress value={87} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1 text-sm">
                              <span>Shelter</span>
                              <span className="font-medium">72%</span>
                            </div>
                            <Progress value={72} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1 text-sm">
                              <span>Medical Aid</span>
                              <span className="font-medium">63%</span>
                            </div>
                            <Progress value={63} className="h-2" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="p-3">
                        <CardTitle className="text-base">Sentiment Forecast (48h)</CardTitle>
                      </CardHeader>
                      <CardContent className="p-3">
                        <div className="space-y-3">
                          <div>
                            <div className="flex justify-between mb-1 text-sm">
                              <span>Positive</span>
                              <span className="font-medium text-green-600">+12%</span>
                            </div>
                            <Progress value={32} className="h-2" indicatorClassName="bg-green-500" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1 text-sm">
                              <span>Neutral</span>
                              <span className="font-medium text-gray-600">-5%</span>
                            </div>
                            <Progress value={28} className="h-2" indicatorClassName="bg-gray-500" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1 text-sm">
                              <span>Negative</span>
                              <span className="font-medium text-red-600">-7%</span>
                            </div>
                            <Progress value={40} className="h-2" indicatorClassName="bg-red-500" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="text-center text-sm text-gray-500 italic">
                    Full predictive analytics module coming soon with interactive forecasting tools.
                  </div>
                </TabsContent>
                
                <TabsContent value="correlation">
                  <div className="rounded-md bg-blue-50 p-4 mb-6">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <span className="material-icons text-blue-500">info</span>
                      </div>
                      <div className="ml-3">
                        <h3 className="text-sm font-medium text-blue-800">Correlation Analysis</h3>
                        <div className="mt-2 text-sm text-blue-700">
                          <p>
                            Correlation analysis helps identify relationships between topics, sentiment changes, and real-world events to improve disaster response coordination.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center items-center py-12">
                    <div className="text-center">
                      <span className="material-icons text-4xl text-gray-300">scatter_plot</span>
                      <h3 className="text-lg font-medium text-gray-700 mt-2">Advanced Correlation Analysis</h3>
                      <p className="text-sm text-gray-500 max-w-md mt-1">
                        This feature is in active development and will be available in the next update.
                      </p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              
              <div className="flex justify-center mt-6">
                <Button variant="outline" className="flex items-center">
                  <span className="material-icons mr-2 text-sm">download</span>
                  Export Analysis Report
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
