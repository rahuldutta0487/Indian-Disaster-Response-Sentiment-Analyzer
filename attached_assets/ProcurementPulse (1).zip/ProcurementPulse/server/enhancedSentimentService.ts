/**
 * Enhanced Sentiment Analysis Service
 * 
 * This service provides advanced NLP analysis capabilities for disaster-related social media content.
 * It's designed to be easily extensible to use real AI APIs (Claude, OpenAI) when API keys are available.
 */

import { Tweet } from "@shared/schema";
import { log } from "./vite";

// Sentiment categories with more granular analysis
export type SentimentCategory = 
  | 'very_negative' 
  | 'negative' 
  | 'slightly_negative' 
  | 'neutral' 
  | 'slightly_positive' 
  | 'positive' 
  | 'very_positive';

// Entity types that can be recognized in tweets
export type EntityType = 
  | 'location'  // Places mentioned
  | 'resource'  // Resources needed or available
  | 'hazard'    // Dangers or threats
  | 'impact'    // Effects of the disaster
  | 'action'    // Actions being taken
  | 'time'      // Temporal references
  | 'person'    // People or organizations mentioned
  | 'other';    // Other entities

export interface Entity {
  text: string;
  type: EntityType;
  confidence: number;
}

export interface EnhancedSentimentResult {
  // Basic sentiment
  sentiment: SentimentCategory;
  sentimentScore: number; // -1.0 to 1.0 for granular scoring
  confidence: number;     // 0.0 to 1.0
  
  // Advanced features
  emotionalStates: Record<string, number>; // e.g. {fear: 0.8, anger: 0.2}
  entities: Entity[];
  urgency: number;        // 0.0 to 1.0 scale for urgency
  actionability: number;  // How actionable the content is
  topKeywords: string[];  // Key terms extracted
  
  // Disaster-specific analysis
  resourceNeeds: string[];  // Resources that may be needed
  safetyThreats: string[];  // Potential dangers mentioned
  impactAssessment: string; // Brief assessment of impact
}

// Lexicon for keyword-based sentiment analysis
const sentimentLexicon = {
  // Negative terms
  'damage': -0.6,
  'destroyed': -0.8,
  'danger': -0.7,
  'emergency': -0.6,
  'evacuation': -0.5,
  'evacuate': -0.5,
  'flood': -0.6,
  'flooding': -0.7,
  'devastation': -0.9,
  'threat': -0.7,
  'crisis': -0.7,
  'disaster': -0.7,
  'death': -0.9,
  'dead': -0.9,
  'fatality': -0.9,
  'fatal': -0.9,
  'victim': -0.7,
  'stranded': -0.7,
  'trapped': -0.8,
  'missing': -0.7,
  'lost': -0.6,
  'hurt': -0.6,
  'injured': -0.7,
  'injury': -0.7,
  'casualties': -0.8,
  'critical': -0.6,
  'severe': -0.6,
  'warning': -0.5,
  'alert': -0.4,
  'broken': -0.5,
  
  // Positive terms
  'rescue': 0.7,
  'saved': 0.8,
  'helping': 0.7,
  'help': 0.6,
  'recovered': 0.6,
  'recovery': 0.6,
  'safe': 0.7,
  'safety': 0.6,
  'survivor': 0.6,
  'evacuated': 0.3, // Mixed sentiment - negative event but positive action
  'prepared': 0.5,
  'relief': 0.7,
  'support': 0.6,
  'assistance': 0.7,
  'aid': 0.7,
  'volunteer': 0.8,
  'donate': 0.7,
  'donation': 0.7,
  'resources': 0.5,
  'shelter': 0.5,
  'protect': 0.6,
  'rebuild': 0.6,
  'restore': 0.6,
  'resilient': 0.7,
  'together': 0.6,
  'community': 0.6,
  'coordinated': 0.5,
  'response': 0.5,
  'thank': 0.8,
  'hope': 0.6
};

// Simple entity recognition based on common patterns in disaster situations
const entityPatterns: Record<EntityType, RegExp[]> = {
  location: [
    /\b(in|at|near|around)\s+([A-Z][a-z]+((\s+[A-Z][a-z]+)+)?)\b/i,
    /\b([A-Z][a-z]+((\s+[A-Z][a-z]+)+)?\s+(area|region|county|state|city))\b/i,
    /\b(north|south|east|west|downtown|uptown|central)\s+([A-Z][a-z]+((\s+[A-Z][a-z]+)+)?)\b/i,
    /\b(neighborhood|district|zone)\b/i
  ],
  resource: [
    /\b(water|food|shelter|supplies|generator|power|electricity|fuel|gas|medical|medicine|blanket|clothing)\b/i,
    /\b(need|needs|required|require|requesting|request|donate|donation|supply|supplies)\b/i
  ],
  hazard: [
    /\b(flood|fire|tornado|hurricane|earthquake|danger|threat|hazard|debris|landslide|mudslide|lightning|wind|storm)\b/i,
    /\b(unstable|collapse|damage|damaged|destroyed|blocked|dangerous|unsafe|risk|warning|severe|extreme)\b/i
  ],
  impact: [
    /\b(destroy|damage|impact|effect|affect|loss|destroy|devastate|devastation|ruin|ruined|flooded|burnt)\b/i,
    /\b(without|no\s+(power|water|electricity|internet|service|cell|connectivity))\b/i
  ],
  action: [
    /\b(evacuate|evacuation|flee|leave|stay|shelter|rescue|help|assist|support|respond|volunteer|donate)\b/i,
    /\b(provide|providing|search|searching|distribute|distributing|coordinate|coordinating|restore|restoring)\b/i
  ],
  time: [
    /\b(now|immediately|urgent|currently|present|today|tomorrow|yesterday|morning|evening|afternoon|night)\b/i,
    /\b(hour|day|week|month|soon|later|after|before|during|while|since|already|still)\b/i,
    /\b(\d+\s+(hour|day|minute|second|week)s?(\s+ago)?)\b/i
  ],
  person: [
    /\b(people|person|citizen|resident|family|families|child|children|elderly|woman|man|official|authorities|government|mayor|governor|rescue|worker|volunteer)\b/i,
    /\b(team|crew|group|unit|force|department|agency|organization|service|center)\b/i
  ],
  other: [
    /\b(update|status|situation|condition|report|info|information|map|photo|video|picture|image)\b/i
  ]
};

// Resource needs keyword mapping
const resourceNeedsKeywords = [
  'water', 'food', 'shelter', 'medical', 'medicine', 'doctor', 'hospital',
  'power', 'electricity', 'generator', 'fuel', 'gas', 'supplies', 'blanket',
  'clothing', 'evacuation', 'transport', 'transportation', 'rescue', 'help',
  'assistance', 'aid', 'support', 'need', 'needs', 'required', 'urgent'
];

// Safety threat keyword mapping
const safetyThreatKeywords = [
  'flood', 'fire', 'tornado', 'hurricane', 'earthquake', 'danger', 'threat',
  'hazard', 'debris', 'landslide', 'mudslide', 'lightning', 'wind', 'storm',
  'unstable', 'collapse', 'damage', 'damaged', 'destroyed', 'blocked', 'dangerous',
  'unsafe', 'risk', 'warning', 'severe', 'extreme', 'death', 'injury'
];

/**
 * Performs enhanced sentiment analysis on a tweet
 * 
 * This function simulates what an advanced NLP API would provide,
 * but uses rule-based approaches for demonstration purposes.
 * 
 * @param tweet The tweet to analyze
 * @returns Enhanced sentiment analysis results
 */
export async function analyzeSentiment(tweet: Tweet): Promise<EnhancedSentimentResult> {
  try {
    const text = tweet.content.toLowerCase();
    const words = text.split(/\s+/);
    
    // Calculate basic sentiment
    let sentimentScore = 0;
    let matchCount = 0;
    
    for (const word of words) {
      const cleanWord = word.replace(/[^\w]/g, '');
      if (cleanWord in sentimentLexicon) {
        // Use type assertion to safely index the object
        sentimentScore += sentimentLexicon[cleanWord as keyof typeof sentimentLexicon];
        matchCount++;
      }
    }
    
    // Normalize sentiment score
    if (matchCount > 0) {
      sentimentScore = sentimentScore / matchCount;
    } else {
      // Default to mild sentiment if no matches
      sentimentScore = parseFloat(tweet.sentimentScore);
    }
    
    // Map to sentiment category
    let sentiment: SentimentCategory;
    if (sentimentScore < -0.7) sentiment = 'very_negative';
    else if (sentimentScore < -0.3) sentiment = 'negative';
    else if (sentimentScore < -0.1) sentiment = 'slightly_negative';
    else if (sentimentScore <= 0.1) sentiment = 'neutral';
    else if (sentimentScore <= 0.3) sentiment = 'slightly_positive';
    else if (sentimentScore <= 0.7) sentiment = 'positive';
    else sentiment = 'very_positive';
    
    // Entity recognition
    const entities: Entity[] = [];
    
    for (const [entityType, patterns] of Object.entries(entityPatterns)) {
      for (const pattern of patterns) {
        const matches = text.match(pattern);
        if (matches) {
          // Add the entity with a confidence between 0.7 and 0.9
          entities.push({
            text: matches[0],
            type: entityType as EntityType,
            confidence: 0.7 + Math.random() * 0.2
          });
        }
      }
    }
    
    // Calculate emotional states
    const emotionalStates: Record<string, number> = {};
    
    // Determine fear level
    if (text.match(/(scared|afraid|fear|terrified|frightened|panic|worried|worry|anxious|anxiety|nervous)/i)) {
      emotionalStates.fear = Math.min(0.5 + Math.abs(sentimentScore), 1.0);
    }
    
    // Determine anger level
    if (text.match(/(angry|anger|furious|outraged|mad|upset|frustrated|frustration)/i)) {
      emotionalStates.anger = Math.min(0.5 + Math.abs(sentimentScore), 1.0);
    }
    
    // Determine hope level
    if (text.match(/(hope|hopeful|optimistic|optimism|better|improve|improving|recovery|rebuild|rebuilding)/i)) {
      emotionalStates.hope = Math.min(0.5 + sentimentScore, 1.0);
    }
    
    // Determine relief level
    if (text.match(/(relief|relieved|safe|rescued|saved|thankful|grateful|blessing|survived)/i)) {
      emotionalStates.relief = Math.min(0.5 + sentimentScore, 1.0);
    }
    
    // Calculate urgency based on keywords and punctuation
    let urgency = 0;
    if (text.match(/(urgent|emergency|immediately|now|asap|hurry|quickly|critical|life.threatening)/i)) {
      urgency += 0.5;
    }
    const exclamationCount = (text.match(/!/g) || []).length;
    urgency += Math.min(exclamationCount * 0.1, 0.3);
    
    // Cap urgency at 1.0
    urgency = Math.min(urgency, 1.0);
    
    // Extract resource needs
    const resourceNeeds = resourceNeedsKeywords
      .filter(keyword => text.includes(keyword))
      .filter((value, index, self) => self.indexOf(value) === index); // Remove duplicates
    
    // Extract safety threats
    const safetyThreats = safetyThreatKeywords
      .filter(keyword => text.includes(keyword))
      .filter((value, index, self) => self.indexOf(value) === index); // Remove duplicates
    
    // Generate impact assessment
    let impactAssessment = '';
    if (sentimentScore < -0.6) {
      impactAssessment = 'Severe negative impact reported';
    } else if (sentimentScore < -0.3) {
      impactAssessment = 'Moderate negative impact reported';
    } else if (sentimentScore < 0) {
      impactAssessment = 'Minor negative impact reported';
    } else if (sentimentScore > 0.6) {
      impactAssessment = 'Significant positive developments reported';
    } else if (sentimentScore > 0.3) {
      impactAssessment = 'Moderate positive developments reported';
    } else if (sentimentScore > 0) {
      impactAssessment = 'Slight positive developments reported';
    } else {
      impactAssessment = 'Neutral impact assessment';
    }
    
    // Add specificity to assessment based on entities
    const locationEntities = entities.filter(e => e.type === 'location').map(e => e.text);
    if (locationEntities.length > 0) {
      impactAssessment += ` in ${locationEntities[0]}`;
    }
    
    // Extract important keywords
    const topKeywords = words
      .map(word => word.replace(/[^\w]/g, ''))
      .filter(word => word.length > 3)
      .filter(word => {
        const key = word as keyof typeof sentimentLexicon;
        return !(key in sentimentLexicon); // Exclude sentiment words
      })
      .filter((value, index, self) => self.indexOf(value) === index) // Remove duplicates
      .slice(0, 5); // Take top 5
    
    // Calculate actionability - content that suggests actions to be taken
    let actionability = 0;
    if (text.match(/(need|help|assist|support|rescue|evacuate|provide|send|donate|volunteer|respond)/i)) {
      actionability += 0.5;
    }
    if (entities.some(e => e.type === 'action')) {
      actionability += 0.3;
    }
    actionability = Math.min(actionability, 1.0);
    
    return {
      sentiment,
      sentimentScore,
      confidence: 0.8, // Simulated confidence score
      emotionalStates,
      entities,
      urgency,
      actionability,
      topKeywords,
      resourceNeeds,
      safetyThreats,
      impactAssessment
    };
  } catch (error) {
    log(`Error in enhanced sentiment analysis: ${error}`, 'error');
    
    // Return a default neutral analysis in case of error
    return {
      sentiment: 'neutral',
      sentimentScore: 0,
      confidence: 0.5,
      emotionalStates: {},
      entities: [],
      urgency: 0,
      actionability: 0,
      topKeywords: [],
      resourceNeeds: [],
      safetyThreats: [],
      impactAssessment: 'Unable to assess impact'
    };
  }
}

/**
 * Analyze a batch of tweets to get aggregated sentiment trends
 * @param tweets Array of tweets to analyze
 * @returns Aggregated sentiment statistics
 */
export async function analyzeMultipleTweets(tweets: Tweet[]) {
  const results = await Promise.all(tweets.map(analyzeSentiment));
  
  // Calculate sentiment distribution
  const sentimentCounts: Record<SentimentCategory, number> = {
    very_negative: 0,
    negative: 0,
    slightly_negative: 0,
    neutral: 0,
    slightly_positive: 0,
    positive: 0,
    very_positive: 0
  };
  
  results.forEach(result => {
    sentimentCounts[result.sentiment]++;
  });
  
  // Calculate most common entities
  const entityFrequency: Record<string, number> = {};
  results.forEach(result => {
    result.entities.forEach(entity => {
      const key = `${entity.type}:${entity.text}`;
      entityFrequency[key] = (entityFrequency[key] || 0) + 1;
    });
  });
  
  // Sort entities by frequency
  const topEntities = Object.entries(entityFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([key, count]) => {
      const [type, text] = key.split(':');
      return { type, text, count };
    });
  
  // Calculate average urgency
  const avgUrgency = results.reduce((sum, result) => sum + result.urgency, 0) / results.length;
  
  // Calculate most mentioned resource needs
  const resourceNeedsFrequency: Record<string, number> = {};
  results.forEach(result => {
    result.resourceNeeds.forEach(need => {
      resourceNeedsFrequency[need] = (resourceNeedsFrequency[need] || 0) + 1;
    });
  });
  
  const topResourceNeeds = Object.entries(resourceNeedsFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([need, count]) => ({ need, count }));
  
  // Calculate most mentioned safety threats
  const safetyThreatsFrequency: Record<string, number> = {};
  results.forEach(result => {
    result.safetyThreats.forEach(threat => {
      safetyThreatsFrequency[threat] = (safetyThreatsFrequency[threat] || 0) + 1;
    });
  });
  
  const topSafetyThreats = Object.entries(safetyThreatsFrequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([threat, count]) => ({ threat, count }));
  
  // Calculate emotional state trends
  const emotionalStateTotals: Record<string, number> = {};
  const emotionalStateCounts: Record<string, number> = {};
  
  results.forEach(result => {
    Object.entries(result.emotionalStates).forEach(([emotion, value]) => {
      emotionalStateTotals[emotion] = (emotionalStateTotals[emotion] || 0) + value;
      emotionalStateCounts[emotion] = (emotionalStateCounts[emotion] || 0) + 1;
    });
  });
  
  const emotionalStateTrends = Object.entries(emotionalStateTotals)
    .map(([emotion, total]) => ({
      emotion,
      averageIntensity: total / emotionalStateCounts[emotion],
      occurrenceRate: emotionalStateCounts[emotion] / results.length
    }))
    .sort((a, b) => b.occurrenceRate - a.occurrenceRate);
  
  return {
    sentimentDistribution: sentimentCounts,
    topEntities,
    averageUrgency: avgUrgency,
    topResourceNeeds,
    topSafetyThreats,
    emotionalStateTrends
  };
}

// Example of how this service would integrate with Claude API
// Uncomment and implement when an API key is available
/* 
export async function analyzeWithClaude(tweet: Tweet): Promise<EnhancedSentimentResult> {
  try {
    const anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
    
    const prompt = `
      Analyze the following social media post related to a disaster:
      "${tweet.content}"
      
      Please provide a detailed analysis in JSON format with these fields:
      - sentiment: the overall sentiment (very_negative, negative, slightly_negative, neutral, slightly_positive, positive, very_positive)
      - sentimentScore: a score between -1 (very negative) and 1 (very positive)
      - confidence: your confidence in this analysis (0.0 to 1.0)
      - emotionalStates: an object mapping emotional states to intensities (0.0 to 1.0), e.g. {"fear": 0.8, "hope": 0.2}
      - entities: array of entities mentioned (each with text, type, and confidence)
      - urgency: how urgent the situation described is (0.0 to 1.0)
      - actionability: how actionable the content is (0.0 to 1.0)
      - topKeywords: array of important keywords
      - resourceNeeds: array of resources that might be needed
      - safetyThreats: array of potential dangers mentioned
      - impactAssessment: a brief assessment of the disaster impact
    `;

    const message = await anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219", // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
      max_tokens: 1000,
      messages: [{ role: "user", content: prompt }],
    });

    // Parse the JSON response
    const content = message.content[0].text;
    const result = JSON.parse(content);
    
    return result;
  } catch (error) {
    log(`Error calling Claude API: ${error}`, 'error');
    // Fall back to local analysis
    return analyzeSentiment(tweet);
  }
}
*/